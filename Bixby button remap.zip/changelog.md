### 10.06.2022
* added a function which changes the key after every reboot.